# Publishd Chatbot Kit — v1.0.0

A drop-in AI chatbot for any business website. Single HTML file, streaming
replies, server-held API key. MIT licensed. Free forever.

> Live demo: https://publishd.app/chat-demo.html
> Repo: https://github.com/HeavenFYouMissed/best-free-business-ai-chatbot-ready-to-go-2026
> Get the latest zip: https://publishd.app/free-ai-chatbot

## What's in this zip

\`\`\`
chat-demo.html        ← the widget. Drop on any static host.
api/chat.ts           ← the streaming proxy. Drop into Next.js as app/api/chat/route.ts
api/system-prompt.ts  ← edit this with your business facts.
.env.example          ← documents the env vars.
LICENSE               ← MIT.
\`\`\`

## Quick start (Next.js)

1. \`npm install groq-sdk\`
2. Copy \`api/chat.ts\` → \`app/api/chat/route.ts\`, and \`api/system-prompt.ts\` next to it.
3. Edit \`system-prompt.ts\` with your business info (prices, hours, links, tone).
4. Put \`chat-demo.html\` in \`public/\` and visit \`/chat-demo.html\`.
5. Add \`GROQ_API_KEY\` to \`.env.local\` (free key: https://console.groq.com/).
6. \`npm run dev\`. The widget hits same-origin \`/api/chat\` automatically.

## Embedding on a different domain

If your HTML page is on \`siteA.com\` but \`/api/chat\` is on \`siteB.com\`,
set \`CHAT_WIDGET_ALLOWED_ORIGINS\` on the API host (see \`.env.example\`).

The default CHAT_API in chat-demo.html points at https://publishd.app/api/chat
when not on localhost or publishd.app — open the file, search for \`resolveChatApi\`
and change it to your own host once you've deployed your API.

## Deploy

Anything that runs Next.js works: Cloudflare Workers (\`@opennextjs/cloudflare\`),
Vercel, Netlify, Railway. Set \`GROQ_API_KEY\` in the host's secrets UI.

## Why free

Most "free" widgets are lead magnets for paid SaaS tiers — usage caps, branding,
your data on their server. This is the opposite: your code, your key, your
hosting, MIT.

If you'd rather hire someone to install + customize it (RAG over your docs,
CRM hand-off, brand styling), see https://publishd.app/ai-chatbots — flat-fee
\$399/$799 installs by Daniel.

— Daniel Castellani · publishd.app · daniel@publishd.app
