// Drop this file into a Next.js project at: app/api/chat/route.ts
// Or adapt for Cloudflare Workers / Express — the streaming logic is portable.
//
// Required env: GROQ_API_KEY  (server-side only — never put in client code)
// Optional env: CHAT_WIDGET_ALLOWED_ORIGINS = "*" or a comma-separated allowlist
//
// Free Groq key: https://console.groq.com/

import Groq from "groq-sdk";
import { SYSTEM_PROMPT } from "./system-prompt";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Msg = { role: "user" | "assistant"; content: string };

function corsHeaders(req: Request): Record<string, string> {
  const raw = process.env.CHAT_WIDGET_ALLOWED_ORIGINS?.trim();
  if (!raw) return {};
  const list = raw.split(",").map((s) => s.trim()).filter(Boolean);
  const base = {
    "access-control-allow-methods": "POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-max-age": "86400",
  };
  if (list.includes("*")) return { ...base, "access-control-allow-origin": "*" };
  const origin = req.headers.get("origin");
  if (origin && list.includes(origin)) {
    return { ...base, "access-control-allow-origin": origin, Vary: "Origin" };
  }
  return {};
}

export async function OPTIONS(req: Request) {
  return new Response(null, { status: 204, headers: corsHeaders(req) });
}

export async function POST(req: Request) {
  const cors = corsHeaders(req);
  let body: { messages?: Msg[] };
  try {
    body = await req.json();
  } catch {
    return new Response("Invalid JSON", { status: 400, headers: cors });
  }
  const messages = (body.messages ?? []).filter(
    (m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string"
  );
  if (messages.length === 0) {
    return new Response("No messages", { status: 400, headers: cors });
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return new Response("GROQ_API_KEY missing on server", { status: 503, headers: cors });
  }
  const client = new Groq({ apiKey });

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        const completion = await client.chat.completions.create({
          model: "openai/gpt-oss-120b",
          temperature: 0.3,
          top_p: 0.9,
          max_tokens: 600,
          stream: true,
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...messages.map((m) => ({ role: m.role, content: m.content })),
          ],
        });
        for await (const chunk of completion) {
          const delta = chunk.choices?.[0]?.delta?.content;
          if (delta) controller.enqueue(encoder.encode(delta));
        }
      } catch (err) {
        controller.enqueue(encoder.encode("\n\nServer error — check Groq key + quota."));
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: { "content-type": "text/plain; charset=utf-8", ...cors },
  });
}
